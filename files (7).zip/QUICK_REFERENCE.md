# Azure Container Apps - Quick Reference Card

## 🚀 Quick Commands

### Deployment
```bash
# Deploy to dev
az deployment group create \
  --resource-group rg-containerapp-dev \
  --template-file infrastructure/container-apps/main.bicep \
  --parameters infrastructure/container-apps/parameters.dev.json

# Preview changes
az deployment group what-if \
  --resource-group rg-containerapp-dev \
  --template-file infrastructure/container-apps/main.bicep \
  --parameters infrastructure/container-apps/parameters.dev.json
```

### Container App Management
```bash
# Get app URL
az containerapp show \
  --name ca-myproject-dev-eastus \
  --resource-group rg-containerapp-dev \
  --query properties.configuration.ingress.fqdn -o tsv

# View logs
az containerapp logs show \
  --name ca-myproject-dev-eastus \
  --resource-group rg-containerapp-dev \
  --follow

# List revisions
az containerapp revision list \
  --name ca-myproject-dev-eastus \
  --resource-group rg-containerapp-dev \
  --output table

# Scale manually
az containerapp update \
  --name ca-myproject-dev-eastus \
  --resource-group rg-containerapp-dev \
  --min-replicas 2 \
  --max-replicas 10

# Restart container app
az containerapp revision restart \
  --name ca-myproject-dev-eastus \
  --resource-group rg-containerapp-dev \
  --revision <revision-name>
```

### Container Registry
```bash
# List images
az acr repository list --name youracr --output table

# Show tags
az acr repository show-tags \
  --name youracr \
  --repository myapp \
  --output table

# Get credentials
az acr credential show --name youracr
```

### Monitoring
```bash
# Get metrics
az monitor metrics list \
  --resource /subscriptions/.../containerApps/ca-myproject-dev-eastus \
  --metric-names "UsageNanoCores,WorkingSetBytes" \
  --start-time 2024-01-01T00:00:00Z

# Query logs
az monitor log-analytics query \
  --workspace <workspace-id> \
  --analytics-query "ContainerAppConsoleLogs_CL | limit 10"
```

## 📋 Parameter File Template

```json
{
  "environmentType": { "value": "dev" },
  "location": { "value": "eastus" },
  "projectName": { "value": "myproject" },
  "containerImage": { "value": "youracr.azurecr.io/myapp:latest" },
  "containerRegistry": { "value": "youracr.azurecr.io" },
  "logAnalyticsWorkspaceId": { "value": "/subscriptions/.../workspaces/..." }
}
```

## 🔧 Troubleshooting Commands

```bash
# Check deployment status
az deployment group show \
  --resource-group rg-containerapp-dev \
  --name main

# Get deployment errors
az deployment group show \
  --resource-group rg-containerapp-dev \
  --name main \
  --query properties.error

# Check container app status
az containerapp show \
  --name ca-myproject-dev-eastus \
  --resource-group rg-containerapp-dev \
  --query properties.runningStatus

# View environment details
az containerapp env show \
  --name cae-myproject-dev-eastus \
  --resource-group rg-containerapp-dev
```

## 📊 Common KQL Queries

```kusto
// Recent errors
ContainerAppConsoleLogs_CL
| where Log_s contains "error" or Log_s contains "exception"
| where TimeGenerated > ago(1h)
| project TimeGenerated, ContainerAppName_s, Log_s

// Request rate
ContainerAppSystemLogs_CL
| where Type_s == "http"
| summarize RequestCount = count() by bin(TimeGenerated, 5m)
| render timechart

// CPU usage
ContainerAppSystemLogs_CL
| where Type_s == "metrics"
| project TimeGenerated, CpuUsage_d
| render timechart
```

## 🔐 Security Commands

```bash
# Enable managed identity
az containerapp identity assign \
  --name ca-myproject-dev-eastus \
  --resource-group rg-containerapp-dev \
  --system-assigned

# Add secret
az containerapp secret set \
  --name ca-myproject-dev-eastus \
  --resource-group rg-containerapp-dev \
  --secrets "api-key=secretvalue123"

# List secrets
az containerapp secret list \
  --name ca-myproject-dev-eastus \
  --resource-group rg-containerapp-dev
```

## 📱 Useful URLs

- Azure Portal: `https://portal.azure.com`
- Container App: `https://ca-myproject-dev-eastus.<random>.eastus.azurecontainerapps.io`
- Azure DevOps: `https://dev.azure.com/yourorg/yourproject`
- ACR: `https://youracr.azurecr.io`

## 💡 Tips

1. Always use `--what-if` before deploying to production
2. Tag your deployments with `--tags DeployedBy=<name> Date=<date>`
3. Use variable groups for environment-specific settings
4. Enable auto-scaling for cost optimization
5. Set up alerts for critical metrics
6. Review logs regularly for errors and warnings
7. Keep documentation updated with changes
