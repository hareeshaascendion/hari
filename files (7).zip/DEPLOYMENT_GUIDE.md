# Azure Container Apps Deployment Guide

## Quick Start Checklist

### Before You Begin
- [ ] Access to Azure subscription with Contributor rights
- [ ] Access to Azure DevOps project
- [ ] Log Analytics Workspace created
- [ ] Azure Container Registry (ACR) set up
- [ ] Service connections configured in Azure DevOps

### Deployment Steps
1. [ ] Create feature branch
2. [ ] Update parameter files with your values
3. [ ] Update pipeline variables
4. [ ] Test deployment in experimental workspace
5. [ ] Commit and push changes
6. [ ] Create pull request
7. [ ] Get approval and merge

---

## Detailed Setup Guide

### 1. Create Required Azure Resources

#### Create Resource Group
```bash
# For dev environment
az group create \
  --name rg-containerapp-dev \
  --location eastus \
  --tags Environment=dev Project=YourProject

# For qa environment
az group create \
  --name rg-containerapp-qa \
  --location eastus \
  --tags Environment=qa Project=YourProject

# For prod environment
az group create \
  --name rg-containerapp-prod \
  --location eastus \
  --tags Environment=prod Project=YourProject
```

#### Create Log Analytics Workspace
```bash
az monitor log-analytics workspace create \
  --resource-group rg-containerapp-dev \
  --workspace-name law-containerapp-dev \
  --location eastus
```

#### Get Log Analytics Workspace ID
```bash
az monitor log-analytics workspace show \
  --resource-group rg-containerapp-dev \
  --workspace-name law-containerapp-dev \
  --query id \
  --output tsv
```

### 2. Configure Parameter Files

Update each parameter file (`parameters.dev.json`, `parameters.qa.json`, `parameters.prod.json`):

```json
{
  "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentParameters.json#",
  "contentVersion": "1.0.0.0",
  "parameters": {
    "environmentType": {
      "value": "dev"  // Change for each environment
    },
    "location": {
      "value": "eastus"  // Your Azure region
    },
    "projectName": {
      "value": "myproject"  // Your project name
    },
    "containerImage": {
      "value": "youracr.azurecr.io/myapp:latest"  // Your container image
    },
    "containerRegistry": {
      "value": "youracr.azurecr.io"  // Your ACR URL
    },
    "logAnalyticsWorkspaceId": {
      "value": "/subscriptions/xxxxx/resourceGroups/rg-containerapp-dev/providers/Microsoft.OperationalInsights/workspaces/law-containerapp-dev"
    }
  }
}
```

### 3. Test Deployment Locally

#### Validate BICEP Template
```bash
# Build BICEP to check for syntax errors
az bicep build --file infrastructure/container-apps/main.bicep

# Validate deployment
az deployment group validate \
  --resource-group rg-containerapp-dev \
  --template-file infrastructure/container-apps/main.bicep \
  --parameters infrastructure/container-apps/parameters.dev.json
```

#### Preview Changes (What-If)
```bash
az deployment group what-if \
  --resource-group rg-containerapp-dev \
  --template-file infrastructure/container-apps/main.bicep \
  --parameters infrastructure/container-apps/parameters.dev.json
```

#### Deploy to Dev
```bash
# Get ACR credentials
ACR_NAME=$(echo "youracr.azurecr.io" | cut -d'.' -f1)
ACR_USERNAME=$(az acr credential show --name $ACR_NAME --query username -o tsv)
ACR_PASSWORD=$(az acr credential show --name $ACR_NAME --query passwords[0].value -o tsv)

# Deploy
az deployment group create \
  --resource-group rg-containerapp-dev \
  --template-file infrastructure/container-apps/main.bicep \
  --parameters infrastructure/container-apps/parameters.dev.json \
  --parameters containerRegistryUsername=$ACR_USERNAME \
  --parameters containerRegistryPassword=$ACR_PASSWORD
```

### 4. Set Up Azure DevOps Pipeline

#### Create Service Connections

1. **Azure Resource Manager Connection**
   - Go to Project Settings > Service connections
   - Click "New service connection"
   - Select "Azure Resource Manager"
   - Choose "Service principal (automatic)"
   - Select your subscription and resource group
   - Name it: `Azure-Service-Connection`

2. **Azure Container Registry Connection**
   - Go to Project Settings > Service connections
   - Click "New service connection"
   - Select "Docker Registry"
   - Choose "Azure Container Registry"
   - Select your ACR
   - Name it: `ACR-Service-Connection`

#### Create Pipeline Variable Group

```bash
# Create variable group (optional, for secrets)
az pipelines variable-group create \
  --organization https://dev.azure.com/yourorg \
  --project YourProject \
  --name ContainerApp-Variables \
  --variables \
    ACR_USERNAME=your-acr-username \
    ACR_PASSWORD=your-acr-password
```

Or create via Azure DevOps UI:
1. Go to Pipelines > Library
2. Click "+ Variable group"
3. Name: `ContainerApp-Variables`
4. Add variables and mark sensitive ones as secret

#### Create Pipeline

1. Go to Pipelines > New Pipeline
2. Select your repository
3. Choose "Existing Azure Pipelines YAML file"
4. Select `azure-pipelines.yml`
5. Review and run

### 5. Configure Environments

Create environments for approval gates:

1. Go to Pipelines > Environments
2. Create three environments:
   - `dev` (no approval required)
   - `qa` (optional approval)
   - `production` (required approval)

3. For production environment:
   - Click on environment
   - Go to "Approvals and checks"
   - Add "Approvals"
   - Add approvers

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────┐
│                    Azure Subscription                    │
│                                                          │
│  ┌────────────────────────────────────────────────────┐ │
│  │         Resource Group (rg-containerapp-dev)        │ │
│  │                                                     │ │
│  │  ┌──────────────────────────────────────────────┐ │ │
│  │  │    Container App Environment                  │ │ │
│  │  │    (cae-myproject-dev-eastus)                │ │ │
│  │  │                                              │ │ │
│  │  │  ┌────────────────────────────────────────┐ │ │ │
│  │  │  │    Container App                        │ │ │ │
│  │  │  │    (ca-myproject-dev-eastus)           │ │ │ │
│  │  │  │                                        │ │ │ │
│  │  │  │  - Auto-scaling (1-5 replicas)        │ │ │ │
│  │  │  │  - External Ingress                   │ │ │ │
│  │  │  │  - HTTPS enabled                      │ │ │ │
│  │  │  │  - Container: from ACR                │ │ │ │
│  │  │  └────────────────────────────────────────┘ │ │ │
│  │  │                                              │ │ │
│  │  │  Logs → Log Analytics Workspace             │ │ │
│  │  └──────────────────────────────────────────────┘ │ │
│  │                                                     │ │
│  │  ┌──────────────────────────────────────────────┐ │ │
│  │  │    Log Analytics Workspace                    │ │ │
│  │  │    (law-containerapp-dev)                    │ │ │
│  │  └──────────────────────────────────────────────┘ │ │
│  └────────────────────────────────────────────────────┘ │
│                                                          │
│  ┌────────────────────────────────────────────────────┐ │
│  │    Azure Container Registry (ACR)                  │ │
│  │    - Container images                              │ │
│  │    - Image tags (dev, qa, prod, latest)           │ │
│  └────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────┘
```

---

## Naming Conventions

All resources follow this naming pattern:

```
{resource-prefix}-{project-name}-{environment}-{location}
```

### Resource Prefixes
- `rg` - Resource Group
- `cae` - Container App Environment
- `ca` - Container App
- `law` - Log Analytics Workspace
- `acr` - Azure Container Registry

### Examples
- `rg-myproject-dev`
- `cae-myproject-dev-eastus`
- `ca-myproject-dev-eastus`
- `law-myproject-dev`

---

## Common Customizations

### 1. Change Scaling Configuration

Edit `container-app.bicep`:
```bicep
scale: {
  minReplicas: 2          // Minimum instances
  maxReplicas: 10         // Maximum instances
  rules: [
    {
      name: 'http-scaling'
      http: {
        metadata: {
          concurrentRequests: '100'  // Requests per instance
        }
      }
    }
  ]
}
```

### 2. Add Environment Variables

Edit parameter files or `container-app.bicep`:
```bicep
env: [
  {
    name: 'ASPNETCORE_ENVIRONMENT'
    value: 'Development'
  }
  {
    name: 'DATABASE_CONNECTION'
    secretRef: 'database-connection-string'
  }
]
```

### 3. Configure Custom Domain

Add to `container-app.bicep`:
```bicep
customDomains: [
  {
    name: 'myapp.example.com'
    bindingType: 'SniEnabled'
    certificateId: certificateResourceId
  }
]
```

### 4. Add Health Probes

```bicep
probes: [
  {
    type: 'Liveness'
    httpGet: {
      path: '/health'
      port: 8000
    }
    periodSeconds: 10
  }
]
```

---

## Monitoring and Alerting

### View Logs in Azure Portal
1. Navigate to your Container App
2. Click "Log stream" in the left menu
3. View real-time logs

### Query Logs with KQL
```kusto
ContainerAppConsoleLogs_CL
| where ContainerAppName_s == "ca-myproject-dev-eastus"
| where TimeGenerated > ago(1h)
| order by TimeGenerated desc
```

### Create Alerts
```bash
az monitor metrics alert create \
  --name 'High CPU Usage' \
  --resource-group rg-containerapp-dev \
  --scopes /subscriptions/.../containerApps/ca-myproject-dev-eastus \
  --condition "avg UsageNanoCores > 800000000" \
  --window-size 5m \
  --evaluation-frequency 1m
```

---

## Security Best Practices

1. **Use Managed Identities**
   - Enable system-assigned identity
   - Grant specific RBAC permissions
   - Avoid storing credentials

2. **Store Secrets in Key Vault**
   ```bicep
   secrets: [
     {
       name: 'api-key'
       keyVaultUrl: 'https://mykv.vault.azure.net/secrets/api-key'
       identity: 'system'
     }
   ]
   ```

3. **Restrict Network Access**
   - Use internal ingress for backend services
   - Configure IP restrictions if needed
   - Use VNet integration for secure communication

4. **Enable HTTPS Only**
   ```bicep
   ingress: {
     allowInsecure: false
     external: true
   }
   ```

---

## Rollback Procedures

### Rollback to Previous Revision
```bash
# List revisions
az containerapp revision list \
  --name ca-myproject-dev-eastus \
  --resource-group rg-containerapp-dev \
  --output table

# Activate previous revision
az containerapp revision activate \
  --name ca-myproject-dev-eastus \
  --resource-group rg-containerapp-dev \
  --revision <revision-name>
```

### Rollback Pipeline Deployment
1. Go to Azure DevOps > Pipelines
2. Select the pipeline run
3. Find the last successful deployment
4. Click "Redeploy"

---

## Cost Optimization

1. **Right-size Resources**
   - Start with 0.5 CPU and 1.0Gi memory
   - Monitor usage and adjust

2. **Use Minimum Replicas Wisely**
   - Dev: minReplicas = 0 (scale to zero)
   - Prod: minReplicas = 2 (high availability)

3. **Enable Auto-scaling**
   - Scale based on demand
   - Avoid over-provisioning

4. **Use Consumption Plan**
   - Pay only for what you use
   - No idle costs when scaled to zero

---

## Next Steps

After successful deployment:

1. [ ] Set up monitoring dashboards
2. [ ] Configure alerting rules
3. [ ] Implement CI/CD for application code
4. [ ] Add custom domain and SSL certificate
5. [ ] Set up backup and disaster recovery
6. [ ] Document application-specific configurations
7. [ ] Train team on operations and troubleshooting

---

## Support and Troubleshooting

### Get Help
- Azure Portal: Check Activity Log and Resource Health
- Azure CLI: Use `--debug` flag for detailed output
- DevOps: Review pipeline logs

### Common Issues

**Issue**: Container fails to start
**Solution**: Check container logs, verify image exists in ACR

**Issue**: Can't access application URL
**Solution**: Verify ingress is enabled and external

**Issue**: High costs
**Solution**: Review replica counts and scale settings

---

## Additional Resources

- [Azure Container Apps Samples](https://github.com/microsoft/container-apps)
- [BICEP Examples](https://github.com/Azure/bicep)
- [Azure DevOps Pipeline Templates](https://github.com/microsoft/azure-pipelines-yaml)
