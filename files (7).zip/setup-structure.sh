#!/bin/bash

# Azure Container Apps Infrastructure Setup Script
# This script creates the recommended folder structure for the deployment

echo "Creating Azure Container Apps infrastructure folder structure..."

# Create main directories
mkdir -p infrastructure/container-apps
mkdir -p pipelines
mkdir -p docs

# Move BICEP files to infrastructure folder
echo "Setting up BICEP templates..."
cp main.bicep infrastructure/container-apps/
cp container-app.bicep infrastructure/container-apps/
cp container-app-environment.bicep infrastructure/container-apps/
cp parameters.dev.json infrastructure/container-apps/
cp parameters.qa.json infrastructure/container-apps/
cp parameters.prod.json infrastructure/container-apps/

# Move pipeline files
echo "Setting up Azure DevOps pipelines..."
cp azure-pipelines.yml pipelines/
cp azure-pipelines-simple.yml pipelines/

# Move documentation
echo "Setting up documentation..."
cp README.md docs/
cp DEPLOYMENT_GUIDE.md docs/

echo "
✅ Folder structure created successfully!

📁 Your project structure:
.
├── infrastructure/
│   └── container-apps/
│       ├── main.bicep
│       ├── container-app-environment.bicep
│       ├── container-app.bicep
│       ├── parameters.dev.json
│       ├── parameters.qa.json
│       └── parameters.prod.json
├── pipelines/
│   ├── azure-pipelines.yml
│   └── azure-pipelines-simple.yml
└── docs/
    ├── README.md
    └── DEPLOYMENT_GUIDE.md

📝 Next steps:
1. Update parameter files with your values
2. Update pipeline variables
3. Create a feature branch: git checkout -b feature/container-app-deployment
4. Commit and push your changes
5. Create a pull request

For detailed instructions, see docs/DEPLOYMENT_GUIDE.md
"
