# Azure Container Apps Deployment

This repository contains BICEP templates and Azure DevOps pipelines for deploying applications to Azure Container Apps.

## 📁 Project Structure

```
infrastructure/
├── container-apps/
│   ├── main.bicep                      # Main orchestration template
│   ├── container-app-environment.bicep # Container App Environment
│   ├── container-app.bicep             # Container App definition
│   ├── parameters.dev.json             # Dev environment parameters
│   ├── parameters.qa.json              # QA environment parameters
│   └── parameters.prod.json            # Prod environment parameters
└── pipelines/
    ├── azure-pipelines.yml             # Full deployment pipeline
    └── azure-pipelines-simple.yml      # Simplified pipeline with ACR
```

## 🚀 Prerequisites

1. **Azure Subscription** with appropriate permissions
2. **Azure DevOps** project with service connections configured
3. **Azure Container Registry** (ACR) for storing container images
4. **Log Analytics Workspace** for monitoring
5. **Service Connections** in Azure DevOps:
   - Azure Resource Manager service connection
   - Azure Container Registry service connection

## 🔧 Setup Instructions

### Step 1: Configure Service Connections

In Azure DevOps:
1. Go to Project Settings > Service Connections
2. Create an Azure Resource Manager connection
3. Create an Azure Container Registry connection

### Step 2: Update Parameters Files

Update the following values in `parameters.dev.json`, `parameters.qa.json`, and `parameters.prod.json`:

```json
{
  "projectName": {
    "value": "your-project-name"
  },
  "containerImage": {
    "value": "youracr.azurecr.io/yourapp:latest"
  },
  "containerRegistry": {
    "value": "youracr.azurecr.io"
  },
  "logAnalyticsWorkspaceId": {
    "value": "/subscriptions/{sub-id}/resourceGroups/{rg}/providers/Microsoft.OperationalInsights/workspaces/{workspace}"
  }
}
```

### Step 3: Update Pipeline Variables

In `azure-pipelines.yml`, update:
- `azureServiceConnection`: Your Azure service connection name
- `acrServiceConnection`: Your ACR service connection name
- `containerRegistry`: Your ACR registry URL
- `imageRepository`: Your container image name

### Step 4: Create Branch and Push Code

```bash
# Create a new branch
git checkout -b feature/container-app-deployment

# Add your files
git add infrastructure/
git add pipelines/

# Commit changes
git commit -m "Add Azure Container Apps deployment"

# Push to remote
git push origin feature/container-app-deployment
```

## 📝 BICEP Templates Explanation

### main.bicep
Orchestrates the deployment of both Container App Environment and Container App.

**Key Features:**
- Manages naming conventions
- Deploys environment first, then app
- Outputs FQDN for accessing the application

### container-app-environment.bicep
Creates the Container App Environment (managed environment for container apps).

**Features:**
- Integration with Log Analytics
- Optional VNet integration
- Zone redundancy support

### container-app.bicep
Deploys the actual Container App.

**Features:**
- Auto-scaling configuration
- Ingress/egress settings
- Container registry authentication
- Environment variables support
- Health probes

## 🔐 Secrets Management

Sensitive values should be stored in Azure DevOps Variable Groups or Azure Key Vault:

1. **Container Registry Credentials**
   ```bash
   # Stored as pipeline variables
   ACR_USERNAME
   ACR_PASSWORD
   ```

2. **Using Key Vault** (Recommended)
   ```yaml
   variables:
     - group: 'KeyVault-Variables'
   ```

## 🚦 Pipeline Stages

### 1. Build Stage
- Validates BICEP templates
- Publishes templates as artifacts

### 2. Deploy Dev
- Creates resource group
- Deploys Container App Environment
- Deploys Container App
- Runs health checks

### 3. Deploy QA
- Requires Dev deployment success
- Deploys to QA environment
- Manual approval gate (optional)

### 4. Deploy Prod
- Requires QA deployment success
- Only triggers on main branch
- Manual approval required

## 🔍 Deployment Commands

### Manual Deployment (Local Testing)

```bash
# Login to Azure
az login

# Set subscription
az account set --subscription "your-subscription-id"

# Create resource group
az group create --name rg-containerapp-dev --location eastus

# Deploy BICEP template
az deployment group create \
  --resource-group rg-containerapp-dev \
  --template-file infrastructure/container-apps/main.bicep \
  --parameters infrastructure/container-apps/parameters.dev.json

# Get Container App URL
az containerapp show \
  --name ca-yourproject-dev-eastus \
  --resource-group rg-containerapp-dev \
  --query properties.configuration.ingress.fqdn \
  --output tsv
```

### What-If Deployment (Preview Changes)

```bash
az deployment group what-if \
  --resource-group rg-containerapp-dev \
  --template-file infrastructure/container-apps/main.bicep \
  --parameters infrastructure/container-apps/parameters.dev.json
```

## 📊 Monitoring and Logs

### View Container App Logs
```bash
az containerapp logs show \
  --name ca-yourproject-dev-eastus \
  --resource-group rg-containerapp-dev \
  --follow
```

### View in Azure Portal
1. Navigate to your Container App
2. Go to "Log stream" for real-time logs
3. Use "Metrics" for performance monitoring

## 🔄 Scaling Configuration

The Container App automatically scales based on:
- HTTP concurrent requests (default: 10)
- Min replicas: 1
- Max replicas: 5

To modify scaling rules, update `container-app.bicep`:
```bicep
scale: {
  minReplicas: 2
  maxReplicas: 10
  rules: [
    {
      name: 'http-scaling'
      http: {
        metadata: {
          concurrentRequests: '50'
        }
      }
    }
  ]
}
```

## 🛠️ Troubleshooting

### Common Issues

1. **Deployment Fails - Log Analytics Workspace**
   - Ensure workspace exists and ID is correct
   - Check permissions on the workspace

2. **Container App Not Starting**
   - Check container registry credentials
   - Verify container image exists
   - Review container logs

3. **Ingress Not Working**
   - Verify targetPort matches your application
   - Check if external ingress is enabled
   - Review NSG rules if using VNet

### Debug Commands

```bash
# Check deployment status
az deployment group show \
  --resource-group rg-containerapp-dev \
  --name main

# List container app revisions
az containerapp revision list \
  --name ca-yourproject-dev-eastus \
  --resource-group rg-containerapp-dev

# Get container app details
az containerapp show \
  --name ca-yourproject-dev-eastus \
  --resource-group rg-containerapp-dev
```

## 📚 References

- [Azure Container Apps Documentation](https://learn.microsoft.com/en-us/azure/container-apps/)
- [BICEP Documentation](https://learn.microsoft.com/en-us/azure/azure-resource-manager/bicep/)
- [Azure DevOps Pipelines](https://learn.microsoft.com/en-us/azure/devops/pipelines/)

## 🤝 Contributing

1. Create a feature branch from `develop`
2. Make your changes
3. Test in experimental/dev environment
4. Create a pull request
5. Get approval from team leads

## 📞 Support

For questions or issues:
- Contact: DevOps Team
- Slack: #devops-support
- Email: devops@yourcompany.com
